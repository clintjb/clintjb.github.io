## Installation

Install dependencies:

```
npm install
```

Compile the code for development and start a local server:

```
npm start
```

Create the build:

```
npm run build
```

Deploy the app with Surge.sh while in the dist directory:

```
npm surge
```